package tests;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import wd.methods.SeMethods;

public class SeLogin extends SeMethods{

	@Test
	public void login()  {
	
		startApp("chrome", "http://leaftaps.com/opentaps");
		WebElement username = locateElement("id", "username");
		type(username, "DemoSalesManager");
		type(locateElement("id", "password"), "crmsfa");
		click(locateElement("class", "decorativeSubmit"));
	//	driver.findElement(By)
		/*driver.findElementById("username").sendKeys("DemoSalesManager");
		driver.findElementById("password").sendKeys("crmsfa");
		driver.findElementByClassName("decorativeSubmit").click();
		driver.findElementByClassName("decorativeSubmit").click();
		
		File src = driver.getScreenshotAs(OutputType.FILE);
		File dest = new File("./snaps/snap1.jpg");
		FileUtils.copyFile(src, dest);
		
		
		
		
		*/
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
